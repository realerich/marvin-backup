# 🛡️ Marvin 备份与恢复系统

完整的灾难恢复方案，防备 OpenClaw 或服务器崩溃。

---

## 📦 备份包内容

每个备份包包含：
- ✅ **18个工具脚本** - 全部功能
- ✅ **配置文件** - API密钥、阈值设置
- ✅ **记忆文件** - 历史记录
- ✅ **数据文件** - 餐厅数据等
- ✅ **根目录配置** - HEARTBEAT.md, SOUL.md等
- ✅ **依赖清单** - Python和系统依赖
- ✅ **恢复脚本** - 一键恢复

---

## 🚀 快速恢复（推荐）

### 1. 如果服务器完全崩溃

```bash
# 1. 安装基础依赖
sudo apt-get update
sudo apt-get install -y python3 python3-pip

# 2. 解压备份包
tar -xzf marvin-tools-*.tar.gz
cd marvin-tools-*

# 3. 运行恢复脚本
./restore.sh

# 4. 安装依赖
./install-deps.sh

# 5. 验证
python3 tools/restore_tools.py verify
```

### 2. 如果OpenClaw可用

```bash
cd /root/.openclaw/workspace

# 一键恢复（自动选择最新备份）
./marvin-restore.sh

# 或指定备份包
./marvin-restore.sh backups/packages/v1.0-complete.tar.gz
```

---

## 📋 备份管理

### 创建新备份

```bash
# 创建带时间戳的备份
python3 tools/backup_tools.py create

# 或指定名称
python3 tools/backup_tools.py create before-upgrade
```

### 列出所有备份

```bash
python3 tools/backup_tools.py list
```

---

## 🔧 手动恢复（高级）

```bash
# 交互式恢复
python3 tools/restore_tools.py restore

# 指定备份包和目标目录
python3 tools/restore_tools.py restore backups/packages/v1.0-complete.tar.gz /path/to/workspace

# 仅安装依赖
python3 tools/restore_tools.py deps

# 验证安装
python3 tools/restore_tools.py verify
```

---

## 💾 定期备份建议

添加到你的 cron（每天自动备份）：

```bash
# 编辑crontab
crontab -e

# 添加每日凌晨3点备份
0 3 * * * cd /root/.openclaw/workspace && python3 tools/backup_tools.py create daily-$(date +\%Y\%m\%d)
```

---

## 📂 备份位置

```
/root/.openclaw/workspace/
├── backups/
│   └── packages/
│       ├── v1.0-complete.tar.gz      # 完整备份包
│       ├── v1.0-complete/            # 解压后的备份
│       │   ├── tools/                # 工具脚本
│       │   ├── config/               # 配置文件
│       │   ├── memory/               # 记忆文件
│       │   ├── data/                 # 数据文件
│       │   ├── restore.sh            # 恢复脚本
│       │   ├── install-deps.sh       # 依赖安装
│       │   ├── dependencies.json     # 依赖清单
│       │   └── README.md             # 备份说明
│       └── ...                       # 其他备份
├── marvin-restore.sh                 # 一键恢复脚本
└── BACKUP-README.md                  # 本文件
```

---

## 🔐 重要提醒

1. **API密钥**: 配置文件包含敏感信息，请妥善保管备份包
2. **定期备份**: 建议在重大变更前创建备份
3. **测试恢复**: 定期测试恢复流程确保可用
4. **异地备份**: 将备份包复制到安全位置（如云存储）

---

## 🆘 紧急恢复流程

如果完全无法访问原服务器：

1. 准备新服务器（Ubuntu 22.04+）
2. 安装基础软件：`sudo apt-get install python3 python3-pip`
3. 复制备份包到新服务器
4. 按"快速恢复"步骤执行
5. 重新配置API密钥（如果需要）
6. 恢复cron任务

---

## 📊 当前备份

最新备份: `v1.0-complete.tar.gz` (55KB)
- 创建时间: 2026-02-16 18:31
- 工具数量: 18个
- 配置文件: 完整
